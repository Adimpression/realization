# See MODULES.md for the repository module map before editing.
from __future__ import annotations

import ast
import unittest
from pathlib import Path


REPO_ROOT = Path("/Users/ravindranathakila/service/realized")
LLM_LAYER_MODULES = (
    REPO_ROOT / "prompt_directives.py",
    REPO_ROOT / "supplement.py",
    REPO_ROOT / "external_markdown_learning_pipeline.py",
    REPO_ROOT / "markdown_learning_artifact_semantics.py",
    REPO_ROOT / "semantic_prompt_posture.py",
)
FORBIDDEN_LAYER_IMPORTS = {
    "approval_governance",
    "capability_runtime",
    "controller_governance_bridge",
    "data_governance",
    "governance_inventory",
    "governed_skill_access",
    "governed_skill_installation",
    "host_abi",
    "host_brokers",
    "host_mediation",
    "macos_host_brokers",
    "skill_governance",
    "skill_lifecycle",
    "skill_safety_governance",
    "virtual_mounts",
}


def module_import_roots(path: Path) -> set[str]:
    """
    High Level Purpose:
        In circumstances like architectural regression testing over the LLM layer, helps with extracting the imported module roots from one Python source file so forbidden layer couplings can be detected without executing the module.

    Reference to Theory:
        Verifies the five-layer architecture boundary by ensuring prompt and LLM modules stay free of governance and runtime-mediation imports.

    Example Input Output:
        Input: `module_import_roots(path=Path('/Users/ravindranathakila/service/realized/supplement.py'))`
        Output: {'json', 'os', 're', 'urllib', 'applied_theory_types'}

    Args:
        path: Value for `path` used by `module_import_roots`. Expected type: `Path`.

    Returns:
        set[str]: Result produced by `module_import_roots`.
    """
    tree = ast.parse(path.read_text())
    imported: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imported.add(str(alias.name).split(".")[0])
        elif isinstance(node, ast.ImportFrom) and node.module:
            imported.add(str(node.module).split(".")[0])
    return imported


class LLMLayerHygieneTests(unittest.TestCase):
    def test_llm_layer_modules_do_not_import_governance_or_runtime_layers(self) -> None:
        """
        High Level Purpose:
            In circumstances like maintaining the five-layer architecture over time, helps with verifying that prompt construction and LLM-supplement modules do not directly depend on governance or runtime-mediation layers.

        Reference to Theory:
            Verifies the architecture boundary that keeps the LLM layer focused on prompt construction and proposal generation rather than on policy, approval, lifecycle, host mediation, or governed installation mechanics.

        Example Input Output:
            Input: `test_llm_layer_modules_do_not_import_governance_or_runtime_layers()`
            Output: None

        Args:
            self: Bound instance that owns the runtime state used by this method.

        Returns:
            None: This function mutates state or performs side effects without returning a value.
        """
        for module_path in LLM_LAYER_MODULES:
            with self.subTest(module=str(module_path.name)):
                imported = module_import_roots(module_path)
                forbidden = sorted(imported & FORBIDDEN_LAYER_IMPORTS)
                self.assertEqual(
                    forbidden,
                    [],
                    msg=f"{module_path.name} imports forbidden layer modules: {', '.join(forbidden)}",
                )
